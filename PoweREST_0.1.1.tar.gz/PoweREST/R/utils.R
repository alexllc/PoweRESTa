# Global variables
# This file is used to declare global variables to avoid R CMD check notes
# PoweREST_Group is a dynamically created column name in Seurat object metadata
utils::globalVariables("PoweREST_Group")

